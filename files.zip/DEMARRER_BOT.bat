@echo off
title Bot CRM Monsieur Pavage
color 0A
echo.
echo  ========================================
echo   BOT CRM MONSIEUR PAVAGE - DEMARRAGE
echo  ========================================
echo.
python --version >nul 2>&1
if errorlevel 1 (echo Python manquant! Va sur python.org & pause & exit)
if not exist ".deps_ok" (
    echo Installation des dependances...
    pip install -r requirements.txt
    echo. > .deps_ok
)
echo  Bot demarre - Ne pas fermer cette fenetre!
echo.
python bot.py
pause
