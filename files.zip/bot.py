import os, json, logging
from datetime import datetime
from dotenv import load_dotenv
from groq import Groq
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (Application, MessageHandler, CommandHandler,
                          CallbackQueryHandler, filters, ContextTypes)
import gspread
from google.oauth2.service_account import Credentials
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

load_dotenv()

TELEGRAM_TOKEN    = os.getenv("TELEGRAM_TOKEN")
GROQ_API_KEY      = os.getenv("GROQ_API_KEY")
GMAIL_ADDRESS     = os.getenv("GMAIL_ADDRESS", "info@monsieurpavage.com")
GMAIL_PASSWORD    = os.getenv("GMAIL_PASSWORD", "")
GOOGLE_SHEET_ID   = os.getenv("GOOGLE_SHEET_ID", "")
GOOGLE_CREDS_FILE = os.getenv("GOOGLE_CREDS_FILE", "google_creds.json")
EXCEL_SCELLANT    = os.getenv("EXCEL_SCELLANT", "scellant_2026.xlsx")
EXCEL_ASPHALTE    = os.getenv("EXCEL_ASPHALTE", "asphalte_2026.xlsx")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler("bot.log", encoding="utf-8"), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)
groq_client = Groq(api_key=GROQ_API_KEY)

COLUMNS = [
    "ID","Date entree","Date install.","Priorite","Statut","Client","Telephone",
    "Courriel","Adresse","Ville","Representant","Type service","Pi2","Montant HT",
    "TPS 5%","TVQ 9.975%","TOTAL","Paiement","Paye","Solde",
    "Notes","SMS J-1","Courriel conf.","Facture","Google/FB/IG","Source"
]

CLIENT_KEYWORDS = [
    "client","nom","tel","telephone","adresse","email","courriel",
    "pieds","pi2","sqft","montant","ville","scellant","asphalte","fissure",
    "nettoyage","travaux","installation","patch","entree"
]

def parse_client_info(message, sender):
    prompt = f"""Tu es un assistant CRM pour Monsieur Pavage Quebec.
Extrait les infos du message et retourne UNIQUEMENT un JSON valide sans aucun texte avant ou apres.
Champs: nom, telephone, courriel, adresse, ville, type_service (Scellant C/S|Asphalte chaude|Asphalte froide|Fissures|Scellant + Fissures|Nettoyage|Patch asphalte), pieds_carres (nombre), montant (nombre decimal), date_installation (YYYY-MM-DD ou null), priorite (1 - Urgent|2 - Normal|3 - Flexible), notes, categorie (SCELLANT ou ASPHALTE).
Si absent mets null.
Message de {sender}: {message}"""
    try:
        r = groq_client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role":"user","content":prompt}],
            temperature=0.1, max_tokens=600
        )
        text = r.choices[0].message.content.strip().replace("```json","").replace("```","").strip()
        data = json.loads(text)
        return data if sum(1 for v in data.values() if v) >= 2 else None
    except Exception as e:
        logger.error(f"IA error: {e}")
        return None

def is_client_msg(text):
    if len(text) < 15: return False
    t = text.lower()
    return sum(1 for kw in CLIENT_KEYWORDS if kw in t) >= 2

def get_or_create_wb(filepath):
    try:
        wb = openpyxl.load_workbook(filepath)
        return wb, wb.active
    except FileNotFoundError:
        wb = Workbook(); ws = wb.active
        ws.title = "Clients 2026"
        ws.append(COLUMNS)
        for cell in ws[1]:
            cell.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
            cell.fill = PatternFill("solid", fgColor="1F4E79")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 28
        widths = [10,13,13,12,14,22,15,26,28,16,15,20,10,13,10,12,13,12,10,10,35,10,12,10,12,12]
        for i,w in enumerate(widths,1):
            ws.column_dimensions[get_column_letter(i)].width = w
        return wb, ws

def save_to_excel(data, sender, msg_text, filepath, prefix):
    try:
        wb, ws = get_or_create_wb(filepath)
        n = ws.max_row
        montant = float(data.get("montant") or 0)
        tps = round(montant*0.05,2); tvq = round(montant*0.09975,2); total = round(montant+tps+tvq,2)
        row = [
            f"{prefix}-2026-{n:03d}",
            datetime.now().strftime("%Y-%m-%d"),
            data.get("date_installation") or "",
            data.get("priorite") or "2 - Normal",
            "Nouveau",
            data.get("nom") or "",
            str(data.get("telephone") or ""),
            data.get("courriel") or "",
            data.get("adresse") or "",
            data.get("ville") or "",
            sender,
            data.get("type_service") or "",
            data.get("pieds_carres") or "",
            montant or "", tps or "", tvq or "", total or "",
            "","","",
            data.get("notes") or "",
            "Non","Non","Non","Non","Telegram"
        ]
        ws.append(row)
        rn = ws.max_row
        alt = PatternFill("solid", fgColor="EBF3FB" if rn%2==0 else "FFFFFF")
        for col in range(1, len(COLUMNS)+1):
            c = ws.cell(row=rn, column=col)
            c.fill = alt; c.font = Font(name="Arial",size=9)
            c.alignment = Alignment(vertical="center")
        for col in [14,15,16,17,19,20]:
            ws.cell(row=rn,column=col).number_format = '#,##0.00 $'
        wb.save(filepath)
        logger.info(f"Excel OK: {data.get('nom')}")
        return True
    except Exception as e:
        logger.error(f"Excel error: {e}"); return False

def save_to_sheets(data, sender, sheet_name):
    if not GOOGLE_SHEET_ID or not os.path.exists(GOOGLE_CREDS_FILE): return False
    try:
        creds = Credentials.from_service_account_file(GOOGLE_CREDS_FILE,
            scopes=["https://www.googleapis.com/auth/spreadsheets"])
        gc = gspread.authorize(creds)
        sh = gc.open_by_key(GOOGLE_SHEET_ID)
        try: ws = sh.worksheet(sheet_name)
        except: ws = sh.add_worksheet(title=sheet_name, rows=1000, cols=26); ws.append_row(COLUMNS)
        montant = float(data.get("montant") or 0)
        tps = round(montant*0.05,2); tvq = round(montant*0.09975,2); total = round(montant+tps+tvq,2)
        ws.append_row([
            datetime.now().strftime("%Y-%m-%d %H:%M"),
            datetime.now().strftime("%Y-%m-%d"),
            data.get("date_installation") or "",
            data.get("priorite") or "2 - Normal","Nouveau",
            data.get("nom") or "", str(data.get("telephone") or ""),
            data.get("courriel") or "", data.get("adresse") or "",
            data.get("ville") or "", sender, data.get("type_service") or "",
            str(data.get("pieds_carres") or ""),
            str(montant) if montant else "", str(tps) if montant else "",
            str(tvq) if montant else "", str(total) if montant else "",
            "","","", data.get("notes") or "",
            "Non","Non","Non","Non","Telegram"
        ], value_input_option="USER_ENTERED")
        logger.info(f"Sheets OK [{sheet_name}]: {data.get('nom')}")
        return True
    except Exception as e:
        logger.error(f"Sheets error: {e}"); return False

async def send_confirmation_email(to_email, nom, service, adresse, ville):
    if not GMAIL_PASSWORD or not to_email: return False
    try:
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        msg = MIMEMultipart("alternative")
        msg["Subject"] = "Confirmation de votre demande - Monsieur Pavage"
        msg["From"] = f"Monsieur Pavage <{GMAIL_ADDRESS}>"
        msg["To"] = to_email
        html = f"""<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
<div style="background:#1F4E79;padding:20px;text-align:center"><h2 style="color:white;margin:0">Monsieur Pavage Inc.</h2></div>
<div style="padding:30px">
<p>Bonjour <b>{nom}</b>,</p>
<p>Nous avons bien recu votre demande pour des travaux de <b>{service}</b> au <b>{adresse}, {ville}</b>.</p>
<p>Notre equipe vous contactera prochainement pour confirmer la date d'installation.</p>
<p>Merci de nous avoir fait confiance!</p>
<p><i>Monsieur Pavage Inc.</i><br>info@monsieurpavage.ca</p>
</div>
<div style="background:#1F4E79;padding:15px;text-align:center">
<p style="color:white;margin:0;font-size:12px">TPS: 730820701 | TVQ: 1222492779 | NEQ: 1177538080</p>
</div></body></html>"""
        msg.attach(MIMEText(html,"html","utf-8"))
        with smtplib.SMTP_SSL("smtpout.secureserver.net", 465, timeout=10) as s:
            s.login(GMAIL_ADDRESS, GMAIL_PASSWORD)
            s.sendmail(GMAIL_ADDRESS, to_email, msg.as_string())
        logger.info(f"Email sent to {to_email}")
        return True
    except Exception as e:
        logger.error(f"Email error: {e}"); return False

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.text: return
    text = msg.text.strip()
    sender = msg.from_user.full_name or msg.from_user.username or "Inconnu"
    if not is_client_msg(text): return
    logger.info(f"MSG from {sender}: {text[:60]}")
    data = parse_client_info(text, sender)
    if not data: return
    cat = data.get("categorie","SCELLANT")
    if cat == "ASPHALTE":
        excel_f, prefix, sheet, emoji = EXCEL_ASPHALTE, "A", "ASPHALTE 2026", "🏗️"
    else:
        excel_f, prefix, sheet, emoji = EXCEL_SCELLANT, "S", "SCELLANT 2026", "🖤"
    excel_ok  = save_to_excel(data, sender, text, excel_f, prefix)
    sheets_ok = save_to_sheets(data, sender, sheet)
    courriel = data.get("courriel")
    email_sent = False
    if courriel:
        email_sent = await send_confirmation_email(
            courriel, data.get("nom",""), data.get("type_service",""),
            data.get("adresse",""), data.get("ville",""))
    nom = data.get("nom") or "—"
    tel = data.get("telephone") or "—"
    ville = data.get("ville") or "—"
    svc = data.get("type_service") or "—"
    pi2 = data.get("pieds_carres") or "—"
    m = data.get("montant")
    m_str = f"{float(m):,.2f} $".replace(",","") if m else "—"
    date_i = data.get("date_installation") or "A confirmer"
    saved = " & ".join(filter(None, ["Excel" if excel_ok else "", "Sheets" if sheets_ok else ""]))
    txt = (f"{emoji} *Client enregistre* | {saved}\n"
           f"{'✉️ Confirmation envoyee\n' if email_sent else ''}"
           f"━━━━━━━━━━━━━━━━\n"
           f"👤 *Nom:* {nom}\n📞 *Tel:* {tel}\n📍 *Ville:* {ville}\n"
           f"🏷 *Service:* {svc}\n📐 *Pi2:* {pi2}\n💰 *Montant:* {m_str}\n"
           f"📅 *Installation:* {date_i}\n👨‍💼 *Rep:* {sender}")
    adresse_maps = f"{data.get('adresse','')} {ville}".replace(" ","+")
    kb = [[
        InlineKeyboardButton("✅ Confirmer", callback_data=f"confirm|{nom}|{tel}"),
        InlineKeyboardButton("🗺️ Route", callback_data=f"route|{adresse_maps}")
    ],[
        InlineKeyboardButton("📄 Facture", callback_data=f"invoice|{nom}|{m or 0}|{svc}"),
        InlineKeyboardButton("❌ Annuler", callback_data=f"cancel|{nom}")
    ]]
    await msg.reply_text(txt.strip(), parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query; await q.answer()
    parts = q.data.split("|"); action = parts[0]
    if action == "confirm":
        nom = parts[1] if len(parts)>1 else "client"
        tel = parts[2] if len(parts)>2 else ""
        await q.edit_message_text(f"✅ *{nom}* confirme!\n📞 {tel}\n_Statut mis a jour → Confirme_", parse_mode="Markdown")
    elif action == "route":
        adr = parts[1] if len(parts)>1 else ""
        url = f"https://www.google.com/maps/dir/?api=1&destination={adr}"
        await q.edit_message_text(f"🗺️ *Route*\n\n[Ouvrir Google Maps]({url})", parse_mode="Markdown")
    elif action == "invoice":
        nom=parts[1] if len(parts)>1 else "Client"
        m=float(parts[2]) if len(parts)>2 else 0
        svc=parts[3] if len(parts)>3 else ""
        tps=m*0.05; tvq=m*0.09975; tot=m+tps+tvq
        await q.edit_message_text(
            f"📄 *Facture — {nom}*\n━━━━━━━━━━━━\n{svc}\nHT: {m:,.2f} $\nTPS: {tps:,.2f} $\nTVQ: {tvq:,.2f} $\n*TOTAL: {tot:,.2f} $*",
            parse_mode="Markdown")
    elif action == "cancel":
        nom = parts[1] if len(parts)>1 else "client"
        await q.edit_message_text(f"❌ *{nom}* annule.", parse_mode="Markdown")

async def cmd_start(update, context):
    await update.message.reply_text("🤖 *Bot CRM Monsieur Pavage actif!*\n\nCommandes:\n/stats - Statistiques\n/aide - Aide", parse_mode="Markdown")

async def cmd_stats(update, context):
    s=a=0
    try: s=openpyxl.load_workbook(EXCEL_SCELLANT).active.max_row-1
    except: pass
    try: a=openpyxl.load_workbook(EXCEL_ASPHALTE).active.max_row-1
    except: pass
    await update.message.reply_text(f"📊 *Stats 2026*\n🖤 Scellant: *{s}*\n🏗️ Asphalte: *{a}*\n👥 Total: *{s+a}*", parse_mode="Markdown")

async def cmd_aide(update, context):
    await update.message.reply_text("📖 Ecris les infos du client dans le groupe et je m'occupe du reste!\n\nEx: _Jean Tremblay 514-555-1234 123 rue Principale Laval scellant 800pi2 450$_", parse_mode="Markdown")

def main():
    if not TELEGRAM_TOKEN: logger.error("TELEGRAM_TOKEN manquant"); return
    if not GROQ_API_KEY: logger.error("GROQ_API_KEY manquant"); return
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("aide", cmd_aide))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logger.info("🚀 Bot CRM Monsieur Pavage demarre!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
